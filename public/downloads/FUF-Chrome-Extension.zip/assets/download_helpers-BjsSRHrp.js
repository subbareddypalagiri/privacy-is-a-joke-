import{c as n,r as g,j as t}from"./index-BvXl80NE.js";/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]],z=n("activity",u);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const x=[["rect",{x:"14",y:"14",width:"4",height:"6",rx:"2",key:"p02svl"}],["rect",{x:"6",y:"4",width:"4",height:"6",rx:"2",key:"xm4xkj"}],["path",{d:"M6 20h4",key:"1i6q5t"}],["path",{d:"M14 10h4",key:"ru81e7"}],["path",{d:"M6 14h2v6",key:"16z9wg"}],["path",{d:"M14 4h2v6",key:"1idq9u"}]],T=n("binary",x);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],L=n("check",f);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],$=n("circle-check",w);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const v=[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]],I=n("download",v);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=[["path",{d:"M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",key:"ct8e1f"}],["path",{d:"M14.084 14.158a3 3 0 0 1-4.242-4.242",key:"151rxh"}],["path",{d:"M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",key:"13bj9a"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]],q=n("eye-off",M);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20",key:"13o1zl"}],["path",{d:"M2 12h20",key:"9i4pu4"}]],R=n("globe",N);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const _=[["rect",{width:"18",height:"11",x:"3",y:"11",rx:"2",ry:"2",key:"1w4ew1"}],["path",{d:"M7 11V7a5 5 0 0 1 10 0v4",key:"fwvmzm"}]],A=n("lock",_);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const j=[["path",{d:"M12 19v3",key:"npa21l"}],["path",{d:"M19 10v2a7 7 0 0 1-14 0v-2",key:"1vc78b"}],["rect",{x:"9",y:"2",width:"6",height:"13",rx:"3",key:"s6n7sd"}]],O=n("mic",j);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=[["path",{d:"M10 8h4",key:"1sr2af"}],["path",{d:"M12 21v-9",key:"17s77i"}],["path",{d:"M12 8V3",key:"13r4qs"}],["path",{d:"M17 16h4",key:"h1uq16"}],["path",{d:"M19 12V3",key:"o1uvq1"}],["path",{d:"M19 21v-5",key:"qua636"}],["path",{d:"M3 14h4",key:"bcjad9"}],["path",{d:"M5 10V3",key:"cb8scm"}],["path",{d:"M5 21v-7",key:"1w1uti"}]],B=n("sliders-vertical",U);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=[["rect",{width:"14",height:"20",x:"5",y:"2",rx:"2",ry:"2",key:"1yt0o3"}],["path",{d:"M12 18h.01",key:"mhygvu"}]],V=n("smartphone",C);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const D=[["path",{d:"m18.84 12.25 1.72-1.71h-.02a5.004 5.004 0 0 0-.12-7.07 5.006 5.006 0 0 0-6.95 0l-1.72 1.71",key:"yqzxt4"}],["path",{d:"m5.17 11.75-1.71 1.71a5.004 5.004 0 0 0 .12 7.07 5.006 5.006 0 0 0 6.95 0l1.71-1.71",key:"4qinb0"}],["line",{x1:"8",x2:"8",y1:"2",y2:"5",key:"1041cp"}],["line",{x1:"2",x2:"5",y1:"8",y2:"8",key:"14m1p5"}],["line",{x1:"16",x2:"16",y1:"19",y2:"22",key:"rzdirn"}],["line",{x1:"19",x2:"22",y1:"16",y2:"16",key:"ox905f"}]],W=n("unlink",D);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const P=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],Z=n("x",P);/**
 * @license lucide-react v1.33.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=[["path",{d:"M15.914 4a1.5 1.5 0 00-2.474-1.561l-9 9A1.5 1.5 0 005.5 14h4.002a.5.5 0 01.471.666L8.086 20a1.5 1.5 0 002.475 1.56l9-9A1.5 1.5 0 0018.5 10h-3.997a.5.5 0 01-.472-.667z",key:"1v7up4"}]],G=n("zap",S),H=({blockedCount:a=0})=>{const[h,c]=g.useState([{id:"1",x:35,y:40,label:"criteo.net",type:"criteo",timestamp:Date.now()},{id:"2",x:65,y:30,label:"facebook.pixel",type:"meta",timestamp:Date.now()},{id:"3",x:75,y:70,label:"doubleclick.net",type:"google",timestamp:Date.now()},{id:"4",x:25,y:75,label:"omnitures.2o7",type:"cname",timestamp:Date.now()}]);return g.useEffect(()=>{const o=[{label:"static.criteo.net",type:"criteo"},{label:"graph.instagram.com",type:"meta"},{label:"google-analytics.com",type:"google"},{label:"disguised.cname.trk",type:"cname"},{label:"stun.webrtc.probe",type:"webrtc"},{label:"webgpu.shader.fuzz",type:"webgpu"}],e=setInterval(()=>{const s=o[Math.floor(Math.random()*o.length)],i=Math.random()*Math.PI*2,d=18+Math.random()*32,l=50+d*Math.cos(i),p=50+d*Math.sin(i),m={id:Math.random().toString(36).substring(2,7),x:l,y:p,label:s.label,type:s.type,timestamp:Date.now()};c(y=>[m,...y.slice(0,4)])},4e3);return()=>clearInterval(e)},[]),t.jsxs("div",{className:"w-full flex flex-col items-center relative",children:[t.jsxs("div",{className:"relative w-44 h-44 sm:w-48 sm:h-48 rounded-full border border-[#27272a] bg-[#070709] flex items-center justify-center overflow-hidden shadow-[inset_0_0_30px_rgba(0,0,0,0.9)] my-2",children:[t.jsx("div",{className:"absolute w-36 h-36 rounded-full border border-[#27272a]/60 border-dashed"}),t.jsx("div",{className:"absolute w-24 h-24 rounded-full border border-[#27272a]"}),t.jsx("div",{className:"absolute w-12 h-12 rounded-full border border-[#27272a]/80"}),t.jsx("div",{className:"absolute w-2 h-2 rounded-full bg-amber-400 z-20 shadow-[0_0_10px_#f59e0b]"}),t.jsx("div",{className:"absolute inset-x-0 top-1/2 h-[1px] bg-[#27272a]/70"}),t.jsx("div",{className:"absolute inset-y-0 left-1/2 w-[1px] bg-[#27272a]/70"}),t.jsx("div",{className:"absolute inset-0 animate-radar-sweep pointer-events-none origin-center",children:t.jsx("div",{className:"w-1/2 h-1/2 absolute top-0 right-0 origin-bottom-left",style:{background:"conic-gradient(from 0deg at 0% 100%, rgba(245, 158, 11, 0.5) 0deg, rgba(245, 158, 11, 0.15) 45deg, transparent 90deg)"}})}),h.map(o=>t.jsxs("div",{className:"absolute z-10 -translate-x-1/2 -translate-y-1/2 group cursor-pointer",style:{left:`${o.x}%`,top:`${o.y}%`},children:[t.jsx("div",{className:"w-2.5 h-2.5 rounded-full bg-red-500 animate-ping absolute opacity-80"}),t.jsx("div",{className:"w-2.5 h-2.5 rounded-full bg-red-500 border border-white shadow-[0_0_10px_#ef4444]"}),t.jsxs("div",{className:"hidden group-hover:block absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-2 py-0.5 rounded bg-black/95 text-white text-[9px] font-mono whitespace-nowrap shadow-xl border border-gray-700 z-30",children:["Sinkholed: ",o.label]})]},o.id))]}),t.jsx("div",{className:"w-full text-center mt-1",children:t.jsx("span",{className:"text-[10px] text-[#71717a] font-mono",children:"Passive Port 53 Zero-Leak Interception"})})]})},Q=({entropyBits:a=2.58,persona:h="Quantum Computing & Topological Matter"})=>{const c=g.useRef(null);return g.useEffect(()=>{var m;const o=c.current;if(!o)return;const e=o.getContext("2d");if(!e)return;let s,i=0;const d=o.width=((m=o.parentElement)==null?void 0:m.clientWidth)||300,l=o.height=70,p=()=>{e.clearRect(0,0,d,l);const y=e.createLinearGradient(0,0,d,0);y.addColorStop(0,"rgba(245, 158, 11, 0.2)"),y.addColorStop(.5,"rgba(251, 191, 36, 1)"),y.addColorStop(1,"rgba(249, 115, 22, 0.3)"),e.beginPath(),e.moveTo(0,l/2);for(let r=0;r<d;r++){const b=l/2+Math.sin(r*.025+i)*16*Math.sin(r*.005+i*.5)+Math.cos(r*.055-i*1.5)*8;e.lineTo(r,b)}e.strokeStyle=y,e.lineWidth=2.4,e.shadowColor="#f59e0b",e.shadowBlur=10,e.stroke(),e.beginPath(),e.moveTo(0,l/2);for(let r=0;r<d;r++){const k=l/2+Math.sin(r*.035-i*.8)*10;e.lineTo(r,k)}e.strokeStyle="rgba(52, 211, 153, 0.4)",e.lineWidth=1.2,e.shadowBlur=0,e.stroke(),i+=.045,s=requestAnimationFrame(p)};return p(),()=>{cancelAnimationFrame(s)}},[]),t.jsxs("div",{className:"w-full flex flex-col justify-between relative overflow-hidden",children:[t.jsx("div",{className:"w-full h-[70px] relative",children:t.jsx("canvas",{ref:c,className:"w-full h-full block"})}),t.jsxs("div",{className:"flex items-center justify-between text-[10px] text-[#71717a] font-mono mt-1 pt-1.5 border-t border-[#27272a]",children:[t.jsxs("span",{className:"truncate max-w-[200px]",children:["Persona: ",t.jsx("strong",{className:"text-white",children:h})]}),t.jsx("span",{className:"text-emerald-400 font-semibold",children:"100% Unpredictable"})]})]})};function X(){const a="FUF-"+Math.random().toString(36).substring(2,10).toUpperCase(),h="FUF-CFG-"+Math.random().toString(36).substring(2,10).toUpperCase(),c=`<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>PayloadDisplayName</key>
    <string>FUF Sovereign Mobile Armor</string>
    <key>PayloadDescription</key>
    <string>Zero-Latency Encrypted DNS & Tracking Sinkhole for iOS / iPadOS</string>
    <key>PayloadOrganization</key>
    <string>FUF Privacy Project</string>
    <key>PayloadType</key>
    <string>Configuration</string>
    <key>PayloadUUID</key>
    <string>${a}</string>
    <key>PayloadVersion</key>
    <integer>1</integer>
    <key>PayloadRemovalDisallowed</key>
    <false/>
    <key>PayloadContent</key>
    <array>
        <dict>
            <key>PayloadType</key>
            <string>com.apple.dnsSettings.managed</string>
            <key>PayloadVersion</key>
            <integer>1</integer>
            <key>PayloadIdentifier</key>
            <string>com.fuf.ios.dns</string>
            <key>PayloadUUID</key>
            <string>${h}</string>
            <key>PayloadDisplayName</key>
            <string>FUF Encrypted DoH</string>
            <key>DNSSettings</key>
            <dict>
                <key>DNSProtocol</key>
                <string>HTTPS</string>
                <key>ServerURL</key>
                <string>https://security.cloudflare-dns.com/dns-query</string>
                <key>ServerAddresses</key>
                <array>
                    <string>1.1.1.2</string>
                    <string>1.0.0.2</string>
                    <string>2606:4700:4700::1112</string>
                    <string>2606:4700:4700::1002</string>
                </array>
            </dict>
        </dict>
    </array>
</dict>
</plist>`,o=new Blob([c],{type:"application/x-apple-aspen-config"}),e=URL.createObjectURL(o),s=document.createElement("a");s.href=e,s.download="FUF-Sovereign-Armor.mobileconfig",document.body.appendChild(s),s.click(),document.body.removeChild(s),setTimeout(()=>URL.revokeObjectURL(e),2e3)}function Y(){const a=document.createElement("a");a.href="/downloads/FUF-Windows-OneClick.zip",a.download="FUF-Windows-OneClick.zip",document.body.appendChild(a),a.click(),document.body.removeChild(a)}function J(){const a=document.createElement("a");a.href="/downloads/FUF-Chrome-Extension.zip",a.download="FUF-Chrome-Extension.zip",document.body.appendChild(a),a.click(),document.body.removeChild(a)}const K="dns.adguard-dns.com";export{z as A,T as B,$ as C,I as D,q as E,R as G,A as L,O as M,V as S,W as U,Z as X,G as Z,L as a,Y as b,J as c,X as d,K as e,H as f,Q as g,B as h};
