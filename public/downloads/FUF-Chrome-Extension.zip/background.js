var D=Object.defineProperty;var y=(e,t,o)=>t in e?D(e,t,{enumerable:!0,configurable:!0,writable:!0,value:o}):e[t]=o;var r=(e,t,o)=>y(e,typeof t!="symbol"?t+"":t,o);import{D as b}from"./assets/dual_zone_router-CN59MhD2.js";const m=["vintage tractor restoration parts","scuba diving drysuit gear iceland","ancient sumerian cuneiform tablets","industrial hydraulic pump maintenance","quantum key distribution protocols","hydroponic saffron farming temperature","origami modular tetrahedron folding","violin bridge acoustic resonance maple","medieval blacksmithing anvil weights","ferrofluid magnetic vortex generators","beekeeping langstroth hive dimensions","geothermal heat pump borehole depth","astrophotography narrowband filter set","sourdough hydration percentage calculators","fpga verilog floating point arithmetic"];class T{constructor(){r(this,"lastDispatchTime",0);r(this,"minIntervalMs",6e4)}getRandomSyntheticQuery(){const t=Math.floor(Math.random()*m.length);return m[t]}shouldDispatch(){const t=Date.now();return t-this.lastDispatchTime>=this.minIntervalMs?(this.lastDispatchTime=t,!0):!1}}const w={enabled:!0,mode:"smart_split",cloakedSearchEngines:!0,protectedBankingDirect:!0};class I{constructor(t=w){r(this,"config");this.config=t}generatePacScript(){return!this.config.enabled||this.config.mode==="direct"?'function FindProxyForURL(url, host) { return "DIRECT"; }':`
      function FindProxyForURL(url, host) {
        // ===================================================================
        // 1. ZONE A: Critical Banking, Payment Gateways & Govt Portals
        // ALWAYS DIRECT ROUTING (Preserves 100% OTP & Anti-Fraud Compliance)
        // ===================================================================
        if (
          dnsDomainIs(host, "onlinesbi.sbi") ||
          dnsDomainIs(host, "retail.onlinesbi.sbi") ||
          dnsDomainIs(host, "hdfcbank.com") ||
          dnsDomainIs(host, "netbanking.hdfcbank.com") ||
          dnsDomainIs(host, "icicibank.com") ||
          dnsDomainIs(host, "axisbank.com") ||
          dnsDomainIs(host, "razorpay.com") ||
          dnsDomainIs(host, "api.razorpay.com") ||
          dnsDomainIs(host, "paytm.com") ||
          dnsDomainIs(host, "uidai.gov.in") ||
          dnsDomainIs(host, "incometax.gov.in") ||
          dnsDomainIs(host, "irctc.co.in") ||
          dnsDomainIs(host, "digilocker.gov.in")
        ) {
          return "DIRECT";
        }

        // ===================================================================
        // 2. High-Bandwidth Direct Media Streaming (0 Buffering)
        // ===================================================================
        if (
          dnsDomainIs(host, "googlevideo.com") ||
          dnsDomainIs(host, "youtube.com") ||
          dnsDomainIs(host, "netflix.com") ||
          dnsDomainIs(host, "nflxvideo.net") ||
          dnsDomainIs(host, "hotstar.com") ||
          dnsDomainIs(host, "spotify.com")
        ) {
          return "DIRECT";
        }

        // ===================================================================
        // 3. High-Surveillance Search Portals (Cloaked Relays)
        // Passes search queries through decentralized open relays with fallback
        // ===================================================================
        if (
          dnsDomainIs(host, "google.com") ||
          dnsDomainIs(host, "google.co.in") ||
          dnsDomainIs(host, "www.google.com") ||
          dnsDomainIs(host, "www.google.co.in") ||
          dnsDomainIs(host, "bing.com") ||
          dnsDomainIs(host, "www.bing.com") ||
          dnsDomainIs(host, "search.yahoo.com")
        ) {
          // Free Decentralized OHTTP & Anycast Relays with seamless DIRECT fallback
          return "SOCKS5 127.0.0.1:9050; HTTPS gateway.cloudflarewarp.com:443; DIRECT";
        }

        return "DIRECT";
      }
    `.trim()}setConfig(t){this.config={...this.config,...t}}getConfig(){return{...this.config}}}const h={enabled:!0,activeZone:"WILD_WEB",currentDomain:"",counters:{trackersBlocked:0,canvasScrambles:0,audioScrambles:0,hardwareMasks:0,poisonQueriesDispatched:0},features:{canvasFarbling:!0,audioFarbling:!0,hardwareSpoofing:!0,webRTCProtection:!0,aiPoisoning:!0,smartBankingWhitelist:!0},trustedDomains:b,recentEvents:[]},S=new T;async function s(){const e=await chrome.storage.local.get("fuf_state");return e&&e.fuf_state?e.fuf_state:(await chrome.storage.local.set({fuf_state:h}),h)}async function a(e){await chrome.storage.local.set({fuf_state:e}),g(e)}function g(e){if(!e.enabled){chrome.action.setBadgeText({text:"OFF"}),chrome.action.setBadgeBackgroundColor({color:"#64748b"});return}const t=e.counters.trackersBlocked+e.counters.canvasScrambles+e.counters.audioScrambles+e.counters.hardwareMasks,o=t>999?"999+":t.toString();chrome.action.setBadgeText({text:o}),chrome.action.setBadgeBackgroundColor({color:e.activeZone==="TRUSTED"?"#22c55e":"#0284c7"})}const E=new I;function l(e){try{if(chrome.proxy&&chrome.proxy.settings)if(e){const t=E.generatePacScript();chrome.proxy.settings.set({value:{mode:"pac_script",pacScript:{data:t}},scope:"regular"},()=>{console.log("[FUF GhostTunnel] 🌐 Smart Split-Tunnel PAC Active (Zone A Direct & Cloaked Relays)")})}else chrome.proxy.settings.set({value:{mode:"direct"},scope:"regular"},()=>{console.log("[FUF GhostTunnel] ⏹️ Direct Routing Restored")})}catch(t){console.debug("[FUF] GhostTunnel setup note:",t)}}function c(e){try{chrome.privacy&&chrome.privacy.network&&chrome.privacy.network.webRTCIPHandlingPolicy&&chrome.privacy.network.webRTCIPHandlingPolicy.set({value:e?"disable_non_proxied_udp":"default"})}catch(t){console.debug("[FUF] WebRTC policy setup:",t)}}async function p(){try{chrome.scripting&&chrome.scripting.registerContentScripts&&((await chrome.scripting.getRegisteredContentScripts()).map(o=>o.id).includes("fuf_main_kernel")&&await chrome.scripting.unregisterContentScripts({ids:["fuf_main_kernel"]}),await chrome.scripting.registerContentScripts([{id:"fuf_main_kernel",matches:["<all_urls>"],js:["content_scripts/injection_kernel.js"],runAt:"document_start",world:"MAIN",allFrames:!0,persistAcrossSessions:!0}]),console.log("[FUF] MAIN World Kernel Registered with CSP Bypass"))}catch(e){console.debug("[FUF] Scripting registration note:",e)}}chrome.alarms.create("ai_poison_timer",{periodInMinutes:2});chrome.alarms.onAlarm.addListener(async e=>{if(e.name==="ai_poison_timer"){const t=await s();if(t.enabled&&t.features.aiPoisoning){const o=S.getRandomSyntheticQuery();t.counters.poisonQueriesDispatched+=1;const n={id:"ev_"+Math.random().toString(36).substr(2,9),timestamp:Date.now(),type:"AI_POISON",domain:"global-ai-graph",details:`Dispatched synthetic entropy: "${o}"`};t.recentEvents=[n,...t.recentEvents.slice(0,49)],await a(t)}}});chrome.runtime.onInstalled.addListener(async()=>{const e=await s();c(e.features.webRTCProtection),l(e.enabled),await p(),g(e),console.log("[FUF] Core Engine Initialized in Manifest V3")});chrome.runtime.onStartup.addListener(async()=>{const e=await s();l(e.enabled),await p()});chrome.runtime.onMessage.addListener((e,t,o)=>((async()=>{const n=await s();switch(e.type){case"GET_STATE":o(n);break;case"TOGGLE_SHIELD":n.enabled=e.payload,c(n.enabled&&n.features.webRTCProtection),l(n.enabled),await a(n),o(n);break;case"TOGGLE_FEATURE":const{feature:d,value:u}=e.payload;n.features[d]=u,d==="webRTCProtection"&&c(n.enabled&&u),await a(n),o(n);break;case"ZONE_DETECTED":n.currentDomain=e.payload.hostname,n.activeZone=e.payload.zone,await a(n),o({success:!0});break;case"LOG_EVENT":const i=e.payload;i.type==="CANVAS_SCRAMBLE"&&(n.counters.canvasScrambles+=1),i.type==="AUDIO_SCRAMBLE"&&(n.counters.audioScrambles+=1),i.type==="HARDWARE_MASK"&&(n.counters.hardwareMasks+=1),i.type==="TRACKER_BLOCKED"&&(n.counters.trackersBlocked+=1),n.recentEvents=[i,...n.recentEvents.slice(0,49)],await a(n),o({success:!0});break;case"ADD_TRUSTED_DOMAIN":n.trustedDomains.includes(e.payload)||(n.trustedDomains.push(e.payload),await a(n)),o(n);break;case"REMOVE_TRUSTED_DOMAIN":n.trustedDomains=n.trustedDomains.filter(f=>f!==e.payload),await a(n),o(n);break;default:o({error:"Unknown message type"})}})(),!0));
